const LogginID = "c1e4b2c3-e8a3-4393-3893-08dc129c0e13";
const Base_URL = "http://localhost:8081/api/";
//const Base_URL = "http://localhost:8081/api/";

export {LogginID, Base_URL}