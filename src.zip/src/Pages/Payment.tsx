import React from 'react'
import LayoutComponent from '../Components/Fixed/LayoutComponent'

function Payment() {
  return (
    <LayoutComponent>
        <div>Payment</div>
    </LayoutComponent>
  )
}

export default Payment