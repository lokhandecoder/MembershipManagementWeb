import React, { useEffect, useState } from "react";
import LayoutComponent from "../Components/Fixed/LayoutComponent";
import GenericTable from "../Components/Fixed/GenericTable";
import { Member } from "../Models/MemberModel";
import {
  FilterDto,
  FollowUpAction,
  FollowUpModel,
} from "../Models/FollowUpModel";
import {
  GetFollowUpAction,
  GetFollowUpBasedOnFilter,
  GetFollowUps,
} from "../Services/FollowUpService";
import {
  Alert,
  Autocomplete,
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Grid,
  InputLabel,
  MenuItem,
  Pagination,
  Select,
  Snackbar,
  TextField,
} from "@mui/material";
import { Await } from "react-router-dom";
import { idText } from "typescript";
import { DemoContainer } from "@mui/x-date-pickers/internals/demo";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { DatePicker } from "@mui/x-date-pickers/DatePicker";
import dayjs from "dayjs";
import useCustomSnackbar from "../Components/useCustomSnackbar";
import { error, log } from "console";
import { all } from "axios";

const FollowUp: React.FC = () => {
  const [errorMessage, setErrorMessage] = useState<string>("");
  const [open, setOpen] = React.useState(false);
  const [selectedFollowUp, setSelectedFollowUp] = useState<string>("");
  const [editMode, setEditMode] = React.useState(false);
  const [followUp, setFollowUp] = useState<FollowUpModel>();
  const [optiondata, setoptionData] = useState<FollowUpModel[]>([]);
  const [alldata, setAllData] = useState<FollowUpModel[]>([]);
  const [MemberOptions, setMemberOptions] = useState<Member[]>([]);
  const [selectedMemebrId, setSelectedMemeberId] = useState<null>(null);
  const [page, setPage] = useState<number>(1);
  const [limit, setLimit] = useState<number>(5);
  const [followUpAction, setFollowUpAction] = useState<FollowUpAction[]>([]);
  const [errors, setErrors] = useState<
    Partial<Record<keyof FollowUpModel, string>>
  >({});
  const [pageCount, setPageCount] = useState<number>(0);
  const [memberId, setMemberId] = useState<string>("");
  const [followUpData, setFollowUpData] = useState<FollowUpModel>({
    id: "",
    memberId: "",
    note: "",
    actionId: 0,
    followUpDate: "",
    nextFollowUpDate: "",
    statusId: 1,
  });

  const [filterDto, setFilterDto] = useState<FilterDto>({
    memberId: null,
    followUpDate: null,
    nextFollowUpDate: null,
  });

  useEffect(() => {
    fetchData();
  }, [selectedMemebrId, page, limit]);

  const snack = useCustomSnackbar();

  const isFormDataValid = (formData: FollowUpModel) => {
    const newErrors: Partial<Record<keyof FollowUpModel, string>> = {};
    if (formData.memberId === "") {
      newErrors.memberId = "Please select the Member.";
    }
    if (formData.followUpDate === "") {
      newErrors.followUpDate = "Please enter a followUp date.";
    }
    if (formData.nextFollowUpDate === "") {
      newErrors.nextFollowUpDate = "Please select nextFollowUpDate";
      snack.showSnackbar(
        `${"Please select nextFollowUpDate."}`,
        "warning",
        { vertical: "top", horizontal: "center" },
        5000
      );
    }
    if (formData.note === "") {
      newErrors.note = "Please enter note";
      snack.showSnackbar(
        `${"Please enter note"}`,
        "warning",
        { vertical: "top", horizontal: "center" },
        5000
      );
    }

    const isValid = Object.keys(newErrors).length === 0;

    setErrors(newErrors);
    return isValid;
  };

  const fetchData = async () => {
    // Fetch gender data

    const MemberOptions = await fetch("http://localhost:8083/api/members").then(
      (response) => response.json()
    );
    setMemberOptions(MemberOptions);
    console.log(MemberOptions);
    const searchoption = await GetFollowUps();
    setoptionData(searchoption[0]);

    const actionOption = await GetFollowUpAction();
    setFollowUpAction(actionOption);
    console.log("actionOption", followUpAction);

    const followUpData = await GetFollowUpBasedOnFilter(filterDto, page, limit);
    setAllData(followUpData.followUps);
    setPageCount(followUpData.totalCount);
    // Fetch member data based on selectedGenderId
    //     if (selectedMemebrId) {
    //       const memberData = await fetch(
    //         `http://localhost:5115/api/followup/GetFollowUpByFilterAsync/${selectedMemebrId}?page=${page}&limit=${limit}`
    //       ).then((response) => response.json());
    //       setData(memberData);
    //       console.log(memberData);

    //       const getData = await fetch(
    //         `http://localhost:5115/api/followup/GetFollowUpByFilterAsync/`
    //       ).then((response) => response.json());

    //       let AllFollowUpCount = getData.length;
    //       setPageCount(AllFollowUpCount);
    //       console.log("pageCount", AllFollowUpCount);
    //     } else {
    //       // Fetch all members if no gender is

    //       const allFollowUp = await fetch(
    //         `http://localhost:5115/api/followup/page/?page=${page}&limit=${limit}`
    //       ).then((response) => response.json());
    //       setData(allFollowUp);

    //       console.log(page, limit);

    //       const getData = await fetch(`http://localhost:5115/api/followup`).then(
    //         (response) => response.json()
    //       );

    //       const AllFollowUpCount = getData.length;
    //       setPageCount(AllFollowUpCount);
    //       setAllData(getData);
    //       console.log("pageCount", AllFollowUpCount);
    //     }
  };

  const [searchTerm, setSearchTerm] = useState<string>("");

  const handleAutocompleteChange = (
    event: React.ChangeEvent<{}>,
    newValue: string | null
  ) => {
    setSearchTerm(newValue || "");
  };
  console.log("optdata", optiondata[0]);
  console.log("alldata", alldata);

  const handleClickOpen = async () => {
    setOpen(true);
    setFollowUp({
      id: "",
      memberId: "",
      note: "",
      followUpDate: "",
      nextFollowUpDate: "",
      actionId: 0,
      statusId: 0,
    });

    const actionOption = await GetFollowUpAction();
    setFollowUpAction(actionOption);
    console.log("actionOption", followUpAction);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const handleSave = async (e: any) => {
    // Assuming you have a backend API endpoint to handle follow-up creation
    e.preventDefault();
    console.log(followUpData);
    let val;
    try {
      if (selectedFollowUp == "") {
        console.log(selectedFollowUp);
        if (!isFormDataValid(followUpData)) {
          console.log("Error", errors);
          val = true;
          console.log(val);
        } else {
          const apiUrl = "http://localhost:5115/api/followup";
          const response = await fetch(apiUrl, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              followUpActionId: followUpData.actionId,
              MemberId: followUpData.memberId,
              Note: followUpData.note,
              FollowUpDate: followUpData.followUpDate,
              NextFollowUpDate: followUpData.nextFollowUpDate,
              StatusId: "1",
            }),
          });
          console.log("Added", followUpData);
          // showSnackbar('Member added successfully');
          snack.showSnackbar(
            `${"Member added successfully"}`,
            "success",
            { vertical: "top", horizontal: "center" },
            5000
          );
          val = false;
          setErrorMessage("");
        }
        setOpen(val);
        fetchData();
      } else {
        console.log("edit", selectedFollowUp);
        if (!isFormDataValid(followUpData)) {
          console.log("Error");
          val = true;
        } else {
          const apiUrl = `http://localhost:5115/api/followup/${selectedFollowUp}`;
          const response = await fetch(apiUrl, {
            method: "PUT",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              MemberId: followUpData.memberId,
              Note: followUpData.note,
              FollowUpDate: followUpData.followUpDate,
              NextFollowUpDate: followUpData.nextFollowUpDate,
              followUpActionId: followUpData.actionId,
              StatusId: "1",
            }),
          });
          console.log(followUp);
          //console.log('Updated Member:', updatedMember);
          // showSnackbar('Member updated successfully');
          snack.showSnackbar(
            `${"Member updated successfully"}`,
            "success",
            { vertical: "top", horizontal: "center" },
            5000
          );
          val = false;
        }

        setOpen(val);
        fetchData();
      }
    } catch (error: any) {
      // alert(JSON.stringify(error))
      console.error("Error saving data:", error.response?.data);
      setOpen(true);
      // showSnackbar(`Error Occurred: ${error.response?.data || 'Unknown error'}`);
      snack.showSnackbar(
        `Error Occurred: ${error.response?.data || "Unknown error"}`,
        "warning",
        { vertical: "top", horizontal: "center" },
        5000
      );
    }
  };

  // const filteredFollowUps = data.filter(
  //   (data) =>
  //     data.followUpDate.toString().includes(searchTerm) ||
  //     data.nextFollowUpDate.toString().includes(searchTerm.toLowerCase())
  // );

  const getMemberNameById = (memberId: string): string => {
    const selectedMember = MemberOptions.find(
      (member) => member.id === memberId
    );
    return selectedMember ? selectedMember.firstName : "";
  };

  const transformedData = alldata.map(({ memberId, statusId, ...rest }) => ({
    memberId: getMemberNameById(memberId),
    ...rest,
  }));

  const handlePageChange = (
    event: React.ChangeEvent<unknown>,
    newPage: number
  ) => {
    //fetchData();
    setPage(newPage);
  };

  const handleEditClick = (item: FollowUpModel) => {

    if (item !== null) {
      const selectedFollowUp = item;
      setOpen(true);
      setEditMode(true);
      console.log(selectedFollowUp);
      setFollowUp({
        id: selectedFollowUp.id,
        memberId: selectedFollowUp.memberId,
        note: selectedFollowUp.note,
        followUpDate: selectedFollowUp.followUpDate,
        nextFollowUpDate: selectedFollowUp.nextFollowUpDate,
        actionId: selectedFollowUp.actionId,
        statusId: selectedFollowUp.statusId,
      });
      setSelectedFollowUp(item.id);
    }
  };

  const handleSearch = async () => {
    try {
      console.log(filterDto);
      //filterDto.memberId = selectedMemebrId;
      if (
        filterDto.memberId !== null ||
        filterDto.followUpDate !== null ||
        filterDto.nextFollowUpDate !== null
      ) {
        const followUpData = await GetFollowUpBasedOnFilter(
          filterDto,
          page,
          limit
        );
        console.log("filteredData", followUpData.followUps);
        setAllData(followUpData.followUps);
        setPageCount(followUpData.followUps.length);

        //fetchDataByGender(Number(selectedGenderId));
      } else {
        fetchData();
      }
      // const membersData = await GetMemberBasedOnFilter(filterDto, currentPage, pageSize);
      // setMembersData(membersData);
      // fetchDataByGender(Number(selectedGenderId));
    } catch (error: any) {
      console.error("Error fetching data:", error);
      // showSnackbar(`${error.response?.data || 'Error occurred'}`);
      snack.showSnackbar(
        `Error Found`,
        "warning",
        { vertical: "top", horizontal: "center" },
        5000
      );
    }

    // const membersData = await GetMemberBasedOnFilter(filterDto, currentPage, pageSize);
    // setMembersData(membersData);
    // fetchDataByGender(Number(selectedGenderId));
  };
  const handleActionClick = async (id: string) => {
    try {
      const apiUrl = `http://localhost:5115/api/followup/${id}`;
      const response = await fetch(apiUrl, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
        },
      });

      if (response.ok) {
        console.log("Follow-up deleted successfully!");
        fetchData();
        // Refresh data or update state after deletion
      } else if (response.status === 404) {
        console.error("Follow-up not found.");
      } else {
        console.error("Error deleting follow-up:", response.statusText);
      }
    } catch (error) {
      console.error("Error deleting follow-up:", error);
    }
  };

  return (
    <LayoutComponent>
      <div style={{ display: "flex", padding: 20, alignItems: "center" }}>
        <Autocomplete
          options={MemberOptions}
          value={
            MemberOptions.find((member) => member.id === followUp?.memberId) ||
            undefined
          }
          getOptionLabel={(member) => member.firstName}
          onChange={(event, newValue) => {
            setFilterDto((previous) => ({
              ...previous,
              memberId: newValue ? newValue.id : null,
            }));
          }}
          renderInput={(params) => (
            <TextField {...params} label="Select a member" variant="outlined" />
          )}
        />

        <Autocomplete
          disablePortal
          id="combo-box-demo"
          options={optiondata.map((followup) =>
            followup.followUpDate.toString()
          )} // replace with your data source
          sx={{ width: 250 }}
          renderInput={(params) => (
            <TextField {...params} label="Search FollowUpDate" />
          )}
          onChange={(event, newValue) => {
            setFilterDto((previous) => ({
              ...previous,
              followUpDate: newValue || null,
            }));
          }}
          style={{ paddingLeft: 20 }}
        />

        <Autocomplete
          disablePortal
          id="combo-box-demo"
          options={optiondata.map((followup) =>
            followup.nextFollowUpDate.toString()
          )} // replace with your data source
          sx={{ width: 250 }}
          renderInput={(params) => (
            <TextField {...params} label="Search NextFollowUpDate" />
          )}
          onChange={(event, newValue) => {
            setFilterDto((previous) => ({
              ...previous,
              nextFollowUpDate: newValue || null,
            }));
          }}
          style={{ paddingLeft: 20 }}
        />
        <Button
          variant="outlined"
          onClick={() => handleSearch()}
          style={{ marginLeft: 20, height: "50px" }}
        >
          Search
        </Button>

        <Button
          variant="outlined"
          onClick={handleClickOpen}
          style={{ marginLeft: "35rem", height: "50px" }}
        >
          Add FollowUp
        </Button>
      </div>
      <Dialog
        open={open}
        onClose={handleClose}
        PaperProps={{
          component: "form",
          onSubmit: (event: React.FormEvent<HTMLFormElement>) => {
            event.preventDefault();
            const formData = new FormData(event.currentTarget);
            const formJson = Object.fromEntries((formData as any).entries());
            handleClose();
          },
        }}
      >
        <DialogTitle>FollowUp Details</DialogTitle>

        <DialogContent style={{ padding: "rem" }}>
          <div style={{ marginTop: "1rem" }}>
            <Autocomplete
              options={MemberOptions}
              value={
                MemberOptions.find(
                  (member) => member.id === followUp?.memberId
                ) || undefined
              }
              // value={
              //   MemberOptions.find(
              //     (member) => member.id === followUp?.memberId
              //   ) || null
              // }

              onChange={(event, newValue) => {
                //setMemberId(newValue ? newValue.id : "");
                setFollowUpData((prev) => ({
                  ...prev,
                  memberId: newValue ? newValue.id : "",
                }));
              }}
              sx={{ width: "100%" }}
              getOptionLabel={(option) => option.firstName}
              renderInput={(params) => (
                <TextField {...params} label="Select Member" />
              )}
            />
            <InputLabel id="demo-simple-select-label">Action</InputLabel>
            <Select
            labelId="demo-simple-select-label"
            id="demo-simple-select"
            //defaultValue={followUp}
            value={followUp?.actionId }
            label="Action"
            sx={{ width: "100%" }}
            onChange={(event) => {
              
              
              const newValue = followUpAction.find((value)=>value.id === Number(event.target.value)) || null;
              setFollowUpData((prev) => ({
                ...prev,
                actionId: newValue ? newValue.id : 0,
                
              }));
            }}
            //renderValue={(selected) => (selected ? selected.followUpActionName : "")}
          >
            {followUpAction?.map((option)=>(
              <MenuItem key = {option.id} value = {option.id}>
                {option.followUpActionName}
              </MenuItem>
            ))}
          </Select>
            
            <TextField
              autoFocus
              required
              margin="dense"
              id="outlined-multiline-static"
              name="Note"
              label="Note"
              type="text"
              fullWidth
              variant="outlined"
              multiline
              rows={4}
              defaultValue={followUp?.note}
              onChange={(e) => {
                setFollowUpData({ ...followUpData, note: e.target.value });
                setErrors((prevErrors) => ({ ...prevErrors, note: "" }));
              }}
              error={!!errors.note}
              helperText={errors.note || ""}
            />

            <Grid
              container
              rowSpacing={1}
              columnSpacing={{ xs: 1, sm: 2, md: 3 }}
            >
              <Grid item xs={6}>
                <LocalizationProvider dateAdapter={AdapterDayjs}>
                  <DatePicker
                    label="FollowUp Date"
                    value={
                      followUp?.followUpDate
                        ? dayjs(followUp.followUpDate)
                        : null
                    }
                    onChange={(date) => {
                      setFollowUpData({
                        ...followUpData,
                        followUpDate: date
                          ? dayjs(date).format("YYYY-MM-DD")
                          : "",
                      });
                      setErrors((prevErrors) => ({
                        ...prevErrors,
                        followUpDate: "",
                      })); // Clear errors when date changes
                    }}

                    // onError={!!errors.followUpDate}
                    // helperText={errors.followUpDate || ""}
                  />
                </LocalizationProvider>
              </Grid>
              <Grid item xs={6}>
                <LocalizationProvider dateAdapter={AdapterDayjs}>
                  <DatePicker
                    label="NextFollowUp Date"
                    value={
                      followUp?.nextFollowUpDate
                        ? dayjs(followUp.nextFollowUpDate)
                        : null
                    }
                    onChange={(date) =>
                      setFollowUpData({
                        ...followUpData,
                        nextFollowUpDate: date
                          ? dayjs(date).format("YYYY-MM-DD")
                          : "",
                      })
                    }
                  />
                </LocalizationProvider>
              </Grid>
            </Grid>
          </div>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>Cancel</Button>
          <Button onClick={handleSave}>Save</Button>
        </DialogActions>
      </Dialog>
      <GenericTable
        data={transformedData}
        onEditClick={handleEditClick}
        onActionClick={handleActionClick}
      ></GenericTable>
      {/* <button onClick={() => { setPage((prevPage) => Math.max(prevPage - 1, 1)); fetchData(); }}>Previous Page</button>
<span> Page {page} </span>
<button onClick={() => { setPage((prevPage) => prevPage + 1); fetchData(); }}>Next Page</button> */}
      <div
        style={{ display: "flex", justifyContent: "center", marginTop: "20px" }}
      >
        <Pagination
          count={Math.ceil(pageCount / limit)}
          variant="outlined"
          shape="rounded"
          onChange={handlePageChange}
        />
        <label>Total FollowUp = {pageCount}</label>
      </div>
      <Snackbar
        open={snack.open}
        autoHideDuration={snack.duration}
        onClose={snack.handleSnackbarClose}
        anchorOrigin={snack.position}
      >
        <Alert
          onClose={snack.handleSnackbarClose}
          severity={snack.severity}
          sx={{ width: "100%" }}
        >
          {snack.message}
        </Alert>
      </Snackbar>
    </LayoutComponent>
  );
};

export default FollowUp;
